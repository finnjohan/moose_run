// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
// Kör: node tests/logic.test.js [antal frön] [meter]
// Datorspelaren springer genom många slumpade skogar. Varje skog ska gå att
// klara, och reglerna för hopp, ducka, filbyte och krockar testas var för sig.
const L = require("./load.js")(["Logic.js"])
let fail = 0
function check(ok, msg) { if (!ok) { fail++; console.log("FEL:", msg) } }
const DT = 1 / 60

function run(s, sec, act) {
    for (let i = 0; i < sec / DT && !s.over; i++) { if (act) act(s, i); L.step(s, DT) }
    return s
}
function clear(s) { s.objects = []; s.nextRowZ = 1e9 }

// ---- Enskilda regler ---------------------------------------------------------
{   // Stubbe rakt fram utan hopp: krock
    const s = L.newGame(1); clear(s); s.objects.push({ id: 1, type: "stump", lane: 0, pz: 8 })
    run(s, 2); check(s.over && s.crashType === "stump", "stubbe utan hopp ska ge krock")
}
{   // Stubbe med hopp: klarar sig
    const s = L.newGame(1); clear(s); s.objects.push({ id: 1, type: "stump", lane: 0, pz: 8 })
    run(s, 2, (s, i) => { if (i === 30) L.input(s, "up") }); check(!s.over, "hopp över stubbe")
}
{   // Gren: ducka går, hopp går inte
    const a = L.newGame(1); clear(a); a.objects.push({ id: 1, type: "branch", lane: 0, pz: 8 })
    run(a, 2, (s, i) => { if (i === 33) L.input(s, "down") }); check(!a.over, "ducka under gren")
    const b = L.newGame(1); clear(b); b.objects.push({ id: 1, type: "branch", lane: 0, pz: 8 })
    run(b, 2, (s, i) => { if (i === 30) L.input(s, "up") }); check(b.over, "hopp under gren ska krocka")
}
{   // Vedtrave: hopp räcker inte, men med stövlar går det
    const a = L.newGame(1); clear(a); a.objects.push({ id: 1, type: "pile", lane: 0, pz: 8 })
    run(a, 2, (s, i) => { if (i === 30) L.input(s, "up") }); check(a.over, "vanligt hopp över vedtrave ska krocka")
    const b = L.newGame(1); clear(b); b.boots = 10; b.objects.push({ id: 1, type: "pile", lane: 0, pz: 8 })
    run(b, 2, (s, i) => { if (i === 25) L.input(s, "up") }); check(!b.over, "stövelhopp över vedtrave")
}
{   // Filbyte in i en vedtrave som redan är bredvid: studs och snubbel, andra gången slut
    const s = L.newGame(1); clear(s)
    s.objects.push({ id: 1, type: "pile", lane: 1, pz: 0 })
    L.input(s, "right"); run(s, 0.3)
    check(!s.over && s.lane === 0 && s.stumbleT > 0, "studs tillbaka vid sidokrock")
    s.objects.push({ id: 2, type: "pile", lane: 1, pz: s.dist })
    L.input(s, "right"); run(s, 0.3)
    check(s.over, "två snubbel i rad ska ge slut")
}
{   // Bär och kraftsaker plockas
    const s = L.newGame(1); clear(s)
    s.objects.push({ id: 1, type: "berry", lane: 0, pz: 5, y: 0.15 }, { id: 2, type: "boots", lane: 0, pz: 7, y: 0.4 },
                   { id: 3, type: "berry", lane: 1, pz: 9, y: 0.15 })
    run(s, 1.2)
    check(s.berries === 1 && s.boots > 0, "plocka bär och stövlar (" + s.berries + ")")
    const k = L.newGame(1); clear(k); k.basket = 5
    k.objects.push({ id: 3, type: "berry", lane: 1, pz: 5, y: 0.15 }, { id: 4, type: "berry", lane: -1, pz: 6, y: 0.15 })
    run(k, 1); check(k.berries === 2, "bärkorgen plockar i alla filer")
}
{   // Vindpusten kör igenom hinder
    const s = L.newGame(1); clear(s); s.wind = 3; s.objects.push({ id: 1, type: "pile", lane: 0, pz: 10 })
    run(s, 1.5); check(!s.over, "vindpust genom vedtrave")
}
{   // Samma frö ger samma skog
    const a = L.newGame(42), b = L.newGame(42)
    check(JSON.stringify(a.objects) === JSON.stringify(b.objects), "samma frö, samma skog")
}

// ---- Datorspelaren genom slumpade skogar -------------------------------------
const seeds = parseInt(process.argv[2] || "40", 10)
const meters = parseInt(process.argv[3] || "6000", 10)
let crashes = 0, totalBerries = 0, rows = { single: 0 }
for (let seed = 1; seed <= seeds; seed++) {
    const s = L.newGame(seed)
    let guard = 0
    while (!s.over && s.dist < meters && guard++ < 1e6) {
        const a = L.bot(s); if (a) L.input(s, a)
        L.step(s, DT)
    }
    totalBerries += s.berries
    // Rader får aldrig spärra alla tre filer med vedtravar
    if (s.over) {
        crashes++
        const near = s.objects.filter(o => Math.abs(o.pz - s.dist) < 6 && L.OBSTACLES[o.type])
            .map(o => o.type + "@" + o.lane + " z=" + (o.pz - s.dist).toFixed(2)).join(", ")
        console.log(`frö ${seed}: krock vid ${s.dist.toFixed(0)} m, fart ${s.speed.toFixed(1)}, fil ${s.lane} x=${s.x.toFixed(2)} y=${s.y.toFixed(2)} duck=${s.slide.toFixed(2)} – ${near}`)
    }
}
check(crashes === 0, `datorspelaren krockade i ${crashes} av ${seeds} skogar`)
console.log(`${seeds} skogar × ${meters} m, i snitt ${(totalBerries / seeds).toFixed(0)} bär`)
console.log(fail ? `${fail} fel` : "alla tester gick igenom")
process.exit(fail ? 1 : 0)
