# Moose Run

An endless runner for Ubuntu Touch. Run through the Swedish forest as a moose: swipe to change path, jump over stumps and fallen trees, duck under branches and steer clear of woodpiles – while picking as many lingonberries as you can.

- Three paths, pseudo-3D in pure QML (no extra libraries)
- Power-ups: rubber boots (jump higher), gust of wind (run through everything) and berry basket (picks berries on all paths)
- Chanterelles for bonus points, a speed that keeps increasing
- Summer, autumn and winter forest (automatic from the calendar or chosen in settings)
- Light, dark (evening) or automatic theme
- English and Swedish
- Records and top runs saved locally (SQLite)
- All characters, graphics and sounds are made for this game

## Svenska

Ett ändlöst löpspel för Ubuntu Touch. Spring genom den svenska skogen som älg: svep för att byta stig, hoppa över stubbar och omkullfallna träd, ducka under grenar och undvik vedtravarna – och plocka så många lingon du kan.

## Build

```bash
clickable build
# or without clickable:
click build <dir with qml/, assets/, manifest.json, mooserun.apparmor, mooserun.desktop, LICENSE>
```

## Development

```bash
node tests/logic.test.js      # rules + a computer player runs through 40 random forests
node tests/i18n.test.js       # every text has a Swedish translation
python3 tools/make_art.py     # regenerates the SVG graphics
python3 tools/make_sounds.py  # regenerates the sound effects (numpy, scipy)
GRID_UNIT_PX=16 UITK_ICON_THEME=suru qmlscene qml/Main.qml --autoplay
```

Test flags: `--demo`, `--autoplay`, `--seed=<n>`, `--lang=sv|en`, `--theme=light|dark`, `--season=summer|autumn|winter`, `--page=game|settings|records`, `--mute`.

The background sounds come from [Kottslungan](https://github.com/finnjohan/kottslungan) by the same author.

## License

GPL-3.0-or-later © 2026 Johan Finn
