#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Skapar spelets ljudeffekter från grunden med numpy (inga inspelningar, inga
# lånade ljud). Kör: python3 tools/make_sounds.py   (kräver numpy och scipy)
# Bakgrundsljuden (ambience-*.ogg) kommer från Kottslungan, samma upphovsperson.
import os, wave
import numpy as np
from scipy.signal import butter, sosfilt

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "sounds")
rng = np.random.default_rng(2026)


def t_of(sec):
    return np.arange(int(sec * SR)) / SR


def band(x, lo, hi):
    return sosfilt(butter(2, [lo, hi], "band", fs=SR, output="sos"), x)


def chirp(f0, f1, sec, harm=(1.0, 0.25)):
    t = t_of(sec)
    f = np.geomspace(f0, f1, len(t))
    ph = 2 * np.pi * np.cumsum(f) / SR
    y = sum(a * np.sin((i + 1) * ph) for i, a in enumerate(harm))
    return y * np.sin(np.pi * t / sec) ** 2


def place(buf, clip, at):
    i = int(at * SR)
    n = min(len(clip), len(buf) - i)
    buf[i:i + n] += clip[:n]


def thud(f, decay, noise_amt, sec=0.25):
    t = t_of(sec)
    body = np.sin(2 * np.pi * f * t * (1 - 0.3 * t)) * np.exp(-t * decay)
    click = sosfilt(butter(2, 3000, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 60) * noise_amt
    return body + click


def bell(freqs, step, sec, decay=7):
    out = np.zeros(int(sec * SR))
    for i, f in enumerate(freqs):
        tt = t_of(0.5)
        note = (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2 * f * tt) * np.exp(-tt * 12)) * np.exp(-tt * decay)
        place(out, note * 0.6, i * step)
    return out


def sfx_jump():          # kort uppåtgående "hopp"
    return chirp(260, 620, 0.22, (1, 0.35, 0.1)) * 0.8 + np.pad(thud(110, 30, 0.4, 0.12), (0, int(0.1 * SR)))[:int(0.22 * SR)] * 0.5


def sfx_slide():         # prassel i mossa och löv
    t = t_of(0.4)
    return band(rng.normal(size=len(t)), 900, 4500) * np.sin(np.pi * t / 0.4) ** 1.5 * 0.7


def sfx_lane():          # svisch
    t = t_of(0.16)
    f = np.geomspace(700, 2200, len(t))
    n = rng.normal(size=len(t))
    return band(n, 800, 3000) * np.sin(np.pi * t / 0.16) ** 2 * 0.5 + 0.05 * np.sin(2 * np.pi * np.cumsum(f) / SR)


def sfx_berry():         # liten klar ton
    return bell([1318.5], 0, 0.25, decay=14) * 1.1


def sfx_shroom():
    return bell([783.99, 987.77, 1318.5], 0.07, 0.6, decay=9)


def sfx_power():
    return bell([523.25, 659.25, 783.99, 1046.5, 1318.5], 0.06, 0.9, decay=6)


def sfx_stumble():
    out = thud(150, 22, 0.8, 0.35)
    place(out, 0.4 * chirp(420, 260, 0.2, (1, 0.5)), 0.05)
    return out


def sfx_crash():
    t = t_of(1.0)
    boom = sosfilt(butter(2, 700, "low", fs=SR, output="sos"), rng.normal(size=len(t))) * np.exp(-t * 6)
    out = 0.9 * boom + 0.9 * thud(90, 9, 0.6, 1.0)
    for k in range(4):     # vedträn som rasar
        place(out, thud(rng.uniform(260, 480), 40, 0.6, 0.15) * 0.5, 0.08 + k * 0.07)
    place(out, bell([392.0, 329.63, 261.63], 0.16, 0.6, decay=6) * 0.5, 0.35)
    return out


def sfx_smash():         # vindpusten blåser undan ett hinder
    t = t_of(0.4)
    return band(rng.normal(size=len(t)), 300, 2400) * np.exp(-t * 8) * 0.9 + 0.5 * thud(200, 30, 0.6, 0.4)


def normalize(y, peak):
    return y / np.max(np.abs(y)) * peak


def write_wav(path, y):
    y = np.clip(y, -1, 1)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((y * 32767).astype(np.int16).tobytes())


def main():
    os.makedirs(OUT, exist_ok=True)
    effects = {
        "jump": (sfx_jump, 0.6), "slide": (sfx_slide, 0.5), "lane": (sfx_lane, 0.35),
        "berry": (sfx_berry, 0.45), "shroom": (sfx_shroom, 0.6), "power": (sfx_power, 0.65),
        "stumble": (sfx_stumble, 0.75), "crash": (sfx_crash, 0.85), "smash": (sfx_smash, 0.7),
    }
    for name, (fn, peak) in effects.items():
        y = normalize(fn(), peak)
        fade = min(len(y), int(0.01 * SR))
        y[-fade:] *= np.linspace(1, 0, fade)
        write_wav(os.path.join(OUT, name + ".wav"), y)
        print(name, f"{len(y) / SR:.2f} s")


if __name__ == "__main__":
    main()
