#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Ritar spelets grafik som SVG. All grafik är gjord för Moose Run.
# Kör: python3 tools/make_art.py   (skriver till assets/)
import os

OUT = os.path.join(os.path.dirname(__file__), "..", "assets")


def svg(w, h, body):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">\n{body}\n</svg>\n'


def write(name, content):
    with open(os.path.join(OUT, name), "w") as f:
        f.write(content)


# ---- Älgen bakifrån ---------------------------------------------------------
FUR = "#6B4426"
FUR_DARK = "#4A2E18"
FUR_MID = "#5A3820"
SOCK = "#D8CFC0"
ANTLER = "#D9C08F"
ANTLER_LINE = "#8A6A3A"


def antlers(cx, cy, s=1.0, droop=0):
    """Breda skovelhorn. cx, cy = mitten mellan hornen."""
    def palm(sign):
        k = sign
        p = [
            (cx + k * 12 * s, cy + 4 * s),
            (cx + k * 30 * s, cy - 2 * s + droop),
            (cx + k * 44 * s, cy - 14 * s + droop),
            (cx + k * 50 * s, cy - 36 * s + droop),    # tagg
            (cx + k * 56 * s, cy - 18 * s + droop),
            (cx + k * 64 * s, cy - 42 * s + droop),    # tagg
            (cx + k * 68 * s, cy - 20 * s + droop),
            (cx + k * 78 * s, cy - 38 * s + droop),    # tagg
            (cx + k * 80 * s, cy - 14 * s + droop),
            (cx + k * 90 * s, cy - 24 * s + droop),    # tagg
            (cx + k * 88 * s, cy - 2 * s + droop),
            (cx + k * 70 * s, cy + 10 * s + droop),
            (cx + k * 40 * s, cy + 12 * s + droop / 2),
            (cx + k * 14 * s, cy + 12 * s),
        ]
        d = "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in p) + " Z"
        return f'<path d="{d}" fill="{ANTLER}" stroke="{ANTLER_LINE}" stroke-width="3" stroke-linejoin="round"/>'
    return palm(-1) + palm(1)


def leg(x, top, bottom, w=20, lift=0):
    """Bakben: brun överdel, ljus 'strumpa', mörk klöv. lift böjer benet uppåt."""
    b = bottom - lift
    mid = top + (b - top) * 0.45
    return (f'<path d="M{x - w / 2},{top} L{x + w / 2},{top} L{x + w / 2 - 2},{mid} L{x - w / 2 + 2},{mid} Z" fill="{FUR_MID}"/>'
            f'<rect x="{x - w / 2 + 3}" y="{mid - 1}" width="{w - 6}" height="{b - mid - 8}" rx="4" fill="{SOCK}"/>'
            f'<path d="M{x - w / 2 + 2},{b - 10} L{x + w / 2 - 2},{b - 10} L{x + w / 2},{b} L{x - w / 2},{b} Z" fill="#2B1B0E"/>')


def moose(frame):
    # viewBox 200×260; marken är y = 258
    if frame == "duck":
        body = (
            antlers(100, 118, 0.95, droop=6)
            + f'<ellipse cx="100" cy="128" rx="22" ry="17" fill="{FUR_DARK}"/>'
            + f'<ellipse cx="74" cy="122" rx="11" ry="6" fill="{FUR_DARK}" transform="rotate(-25 74 122)"/>'
            + f'<ellipse cx="126" cy="122" rx="11" ry="6" fill="{FUR_DARK}" transform="rotate(25 126 122)"/>'
            + leg(66, 205, 258, 22, 0) + leg(134, 205, 258, 22, 0)
            + f'<ellipse cx="100" cy="190" rx="70" ry="46" fill="{FUR}"/>'
            + f'<ellipse cx="100" cy="182" rx="52" ry="28" fill="#7C5230" opacity="0.6"/>'
            + f'<ellipse cx="100" cy="160" rx="8" ry="10" fill="{FUR_DARK}"/>'
        )
        return svg(200, 260, body)
    left_lift = 18 if frame == "b" else 0
    right_lift = 18 if frame == "a" else 0
    body = (
        antlers(100, 46)
        + f'<ellipse cx="100" cy="60" rx="23" ry="21" fill="{FUR_DARK}"/>'
        + f'<ellipse cx="70" cy="54" rx="13" ry="7" fill="{FUR_DARK}" transform="rotate(-25 70 54)"/>'
        + f'<ellipse cx="130" cy="54" rx="13" ry="7" fill="{FUR_DARK}" transform="rotate(25 130 54)"/>'
        + f'<ellipse cx="100" cy="104" rx="52" ry="42" fill="{FUR_MID}"/>'          # manke
        + f'<path d="M82,72 Q100,62 118,72 L114,96 Q100,90 86,96 Z" fill="{FUR_DARK}" opacity="0.7"/>'
        + leg(68, 185, 258, 20, left_lift) + leg(132, 185, 258, 20, right_lift)
        + f'<ellipse cx="100" cy="158" rx="62" ry="54" fill="{FUR}"/>'             # bakdel
        + f'<ellipse cx="100" cy="150" rx="44" ry="34" fill="#7C5230" opacity="0.6"/>'
        + f'<ellipse cx="100" cy="122" rx="8" ry="11" fill="{FUR_DARK}"/>'          # svans
    )
    return svg(200, 260, body)


# ---- Hinder -------------------------------------------------------------------
def stump():
    # 1,3 × 0,85 m → 156 × 102
    return svg(156, 102, """
<path d="M8,102 Q14,90 22,86 L22,22 L134,22 L134,86 Q142,90 148,102 Z" fill="#6E4A2B"/>
<path d="M40,30 L38,96 M62,28 L64,98 M92,28 L90,98 M116,30 L118,96" stroke="#4F331C" stroke-width="4" stroke-linecap="round"/>
<ellipse cx="78" cy="22" rx="56" ry="16" fill="#E4C48F" stroke="#9C7443" stroke-width="3"/>
<ellipse cx="78" cy="22" rx="38" ry="10" fill="none" stroke="#B88E57" stroke-width="2"/>
<ellipse cx="78" cy="22" rx="20" ry="5" fill="none" stroke="#B88E57" stroke-width="2"/>
<path d="M22,60 Q30,46 46,52 Q40,66 22,70 Z" fill="#6B9A3A"/>
<path d="M134,74 Q124,64 112,72 Q120,82 134,82 Z" fill="#6B9A3A"/>
""")


def branch(season):
    # Omkullfallen gran i huvudhöjd, vilande på två klykor. 1,6 × 2,1 m → 168 × 220
    needles = {"summer": "#2F5A2E", "autumn": "#3B5A2C", "winter": "#2C4A36"}[season]
    snow = '<path d="M6,46 Q40,30 84,40 Q128,30 162,46 L162,52 L6,52 Z" fill="#F4F8FB"/>' if season == "winter" else ""
    return svg(168, 220, f"""
<path d="M18,220 L24,96 L14,72 M24,96 L34,74" stroke="#5A3D22" stroke-width="9" stroke-linecap="round" fill="none"/>
<path d="M150,220 L144,96 L154,72 M144,96 L134,74" stroke="#5A3D22" stroke-width="9" stroke-linecap="round" fill="none"/>
<path d="M0,18 Q20,0 40,16 Q60,0 84,14 Q108,0 128,16 Q148,0 168,18 L168,56 L0,56 Z" fill="{needles}"/>
<path d="M10,30 L4,8 M44,26 L40,4 M84,24 L84,2 M124,26 L128,4 M158,30 L164,8" stroke="{needles}" stroke-width="6" stroke-linecap="round"/>
{snow}
<rect x="0" y="50" width="168" height="40" rx="18" fill="#7A5634"/>
<path d="M12,62 L60,60 M80,74 L140,72 M30,80 L70,82" stroke="#5A3D22" stroke-width="3" stroke-linecap="round"/>
<path d="M20,90 L18,104 M60,90 L64,110 M110,90 L106,102 M150,90 L152,106" stroke="{needles}" stroke-width="5" stroke-linecap="round"/>
""")


def pile(season):
    # Vedtrave med kubbar, 1,5 × 2,4 m → 150 × 240
    ends = []
    r = 15
    y = 226
    row = 0
    while y > 40:
        off = 0 if row % 2 == 0 else r
        x = 20 + off
        while x <= 130:
            ends.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="#E1C28E" stroke="#8C6435" stroke-width="3"/>'
                        f'<circle cx="{x}" cy="{y}" r="{r * 0.45:.1f}" fill="none" stroke="#B78E57" stroke-width="1.6"/>')
            x += 2 * r
        y -= 26
        row += 1
    top = ('<path d="M-4,30 L75,6 L154,30 L154,40 L-4,40 Z" fill="#F4F8FB"/>' if season == "winter"
           else '<path d="M-4,32 L75,10 L154,32 L154,42 L-4,42 Z" fill="#5C5048"/><path d="M-4,32 L75,10 L154,32" stroke="#3E352F" stroke-width="3" fill="none"/>')
    return svg(150, 240, f"""
<rect x="2" y="36" width="10" height="204" fill="#5A3D22"/>
<rect x="138" y="36" width="10" height="204" fill="#5A3D22"/>
<rect x="6" y="40" width="138" height="200" fill="#4A321C"/>
{''.join(ends)}
{top}
""")


def fallen_log(season):
    # Omkullfallen stam över hela stigen, 5,4 × 0,8 m → 540 × 80
    moss = {"summer": "#6B9A3A", "autumn": "#8A8A34", "winter": "#F4F8FB"}[season]
    return svg(540, 80, f"""
<rect x="20" y="14" width="510" height="62" rx="26" fill="#6E4A2B"/>
<path d="M60,30 L180,28 M220,46 L360,44 M380,30 L500,32 M90,60 L240,62 M300,62 L470,60" stroke="#4F331C" stroke-width="4" stroke-linecap="round"/>
<path d="M120,16 L112,0 M300,16 L310,0 M430,16 L424,2" stroke="#5A3D22" stroke-width="7" stroke-linecap="round"/>
<path d="M40,18 Q120,4 220,16 Q300,6 380,16 Q460,6 520,20 L520,26 L40,26 Z" fill="{moss}"/>
<ellipse cx="24" cy="45" rx="16" ry="31" fill="#E4C48F" stroke="#9C7443" stroke-width="3"/>
<ellipse cx="24" cy="45" rx="9" ry="18" fill="none" stroke="#B88E57" stroke-width="2"/>
""")


# ---- Saker att plocka ---------------------------------------------------------
def lingon():
    return svg(64, 64, """
<path d="M32,30 Q16,10 4,14 Q12,30 32,30 Z" fill="#3E7A35"/>
<path d="M32,30 Q48,8 60,12 Q52,30 32,30 Z" fill="#4C8A3E"/>
<circle cx="22" cy="40" r="12" fill="#C8102E"/><circle cx="42" cy="40" r="12" fill="#D91A36"/><circle cx="32" cy="52" r="11" fill="#B50E28"/>
<circle cx="18" cy="35" r="3.5" fill="#FFFFFF" opacity="0.7"/><circle cx="38" cy="35" r="3.5" fill="#FFFFFF" opacity="0.7"/><circle cx="28" cy="48" r="3" fill="#FFFFFF" opacity="0.6"/>
""")


def chanterelle():
    return svg(80, 80, """
<path d="M30,74 Q26,52 18,38 L62,38 Q54,52 50,74 Z" fill="#E9A52A"/>
<path d="M4,30 Q10,14 40,12 Q70,14 76,30 Q66,42 40,40 Q14,42 4,30 Z" fill="#F4B830"/>
<path d="M20,38 L32,62 M30,40 L38,66 M44,40 L42,66 M56,38 L48,62" stroke="#D08A1C" stroke-width="2"/>
<path d="M10,26 Q24,18 40,18" stroke="#FFE08A" stroke-width="4" stroke-linecap="round" fill="none"/>
""")


def boots():
    one = lambda x: f"""
<path d="M{x},6 L{x + 22},6 L{x + 24},50 Q{x + 44},52 {x + 46},64 L{x + 46},72 L{x - 2},72 L{x},6 Z" fill="#2E7D32"/>
<rect x="{x - 2}" y="66" width="48" height="6" fill="#1B4D1E"/><rect x="{x}" y="6" width="22" height="7" fill="#4CAF50"/>"""
    return svg(110, 80, one(8) + one(56))


def wind():
    return svg(80, 80, """
<path d="M8,30 Q40,30 50,18 Q58,6 46,6 Q36,8 40,18" stroke="#FFFFFF" stroke-width="6" fill="none" stroke-linecap="round"/>
<path d="M8,44 Q48,44 62,40 Q76,36 72,26 Q66,18 58,26" stroke="#E3F2FD" stroke-width="6" fill="none" stroke-linecap="round"/>
<path d="M14,58 Q40,58 52,64 Q62,72 52,76" stroke="#FFFFFF" stroke-width="5" fill="none" stroke-linecap="round"/>
<path d="M58,52 Q72,46 76,58 Q66,66 58,52 Z" fill="#8BC34A"/>
""")


def basket():
    return svg(84, 80, """
<path d="M14,30 Q42,-6 70,30" stroke="#8C6435" stroke-width="6" fill="none"/>
<circle cx="28" cy="32" r="9" fill="#C8102E"/><circle cx="44" cy="28" r="9" fill="#D91A36"/><circle cx="58" cy="33" r="9" fill="#B50E28"/>
<circle cx="36" cy="36" r="8" fill="#3949AB"/><circle cx="52" cy="38" r="8" fill="#283593"/>
<path d="M6,36 L78,36 L68,76 L16,76 Z" fill="#C9A06A"/>
<path d="M10,48 L74,48 M13,60 L71,60 M30,36 L28,76 M54,36 L56,76" stroke="#8C6435" stroke-width="3"/>
""")


# ---- Träd vid sidan av stigen -------------------------------------------------
def spruce(season):
    green = {"summer": "#24502C", "autumn": "#2B4E2C", "winter": "#24452E"}[season]
    tiers = []
    for i, (y, w) in enumerate([(30, 22), (70, 34), (110, 46), (150, 56), (190, 64), (230, 72)]):
        tiers.append(f'<path d="M60,{y - 40} L{60 + w},{y + 18} L{60 - w},{y + 18} Z" fill="{green}"/>')
        if season == "winter":
            tiers.append(f'<path d="M60,{y - 40} L{60 + w * 0.3:.0f},{y - 22} Q60,{y - 18} {60 - w * 0.3:.0f},{y - 22} Z" fill="#F4F8FB"/>'
                         f'<path d="M{60 + w - 4},{y + 15} L{60 + w},{y + 18} L{60 - w},{y + 18} L{60 - w + 4},{y + 15} Z" fill="#F4F8FB" opacity="0.9"/>')
    return svg(120, 300, '<rect x="54" y="240" width="12" height="60" fill="#4A321C"/>' + "".join(tiers))


def pine(season):
    crown = {"summer": "#2F5E2E", "autumn": "#36592C", "winter": "#2E4F36"}[season]
    snow = ('<path d="M18,56 Q40,40 60,48 Q80,38 102,54 L100,60 Q80,48 60,56 Q40,48 20,62 Z" fill="#F4F8FB"/>'
            if season == "winter" else "")
    return svg(120, 300, f"""
<path d="M54,300 L56,70 L64,70 L66,300 Z" fill="#B5652E"/>
<path d="M58,120 L36,96 M62,150 L86,124" stroke="#9A5226" stroke-width="5" stroke-linecap="round"/>
<ellipse cx="60" cy="70" rx="52" ry="30" fill="{crown}"/>
<ellipse cx="34" cy="96" rx="22" ry="12" fill="{crown}"/><ellipse cx="88" cy="124" rx="22" ry="12" fill="{crown}"/>
{snow}
""")


def birch(season):
    if season == "winter":
        crown = '<path d="M60,60 L30,20 M60,80 L92,30 M60,100 L24,64 M60,110 L98,74 M44,40 L40,14 M80,50 L90,18" stroke="#6A5A4E" stroke-width="3" stroke-linecap="round"/>'
    else:
        c1, c2 = {"summer": ("#5E9E3A", "#7BB54A"), "autumn": ("#E2A62A", "#F2C94C")}[season]
        crown = (f'<ellipse cx="60" cy="70" rx="50" ry="56" fill="{c1}"/>'
                 f'<ellipse cx="44" cy="56" rx="26" ry="28" fill="{c2}" opacity="0.8"/>'
                 f'<ellipse cx="80" cy="90" rx="24" ry="24" fill="{c2}" opacity="0.6"/>')
    return svg(120, 300, f"""
<path d="M54,300 L56,60 L64,60 L67,300 Z" fill="#F2EFE8"/>
<path d="M55,150 L62,148 M57,190 L66,192 M55,230 L60,228 M58,260 L66,262 M56,120 L63,118" stroke="#2B2B2B" stroke-width="4" stroke-linecap="round"/>
{crown}
""")


def rock(season):
    snow = '<path d="M14,30 Q40,4 74,18 Q90,24 96,40 Q60,26 14,40 Z" fill="#F4F8FB"/>' if season == "winter" else \
           '<path d="M20,34 Q36,26 50,30 Q38,38 20,40 Z" fill="#6B9A3A" opacity="0.9"/>'
    return svg(110, 70, f"""
<path d="M4,70 Q6,30 30,16 Q56,2 80,14 Q104,28 106,70 Z" fill="#8A8A86"/>
<path d="M30,20 Q50,12 70,18" stroke="#A8A8A2" stroke-width="5" fill="none" stroke-linecap="round"/>
{snow}
""")


# ---- Ikon ---------------------------------------------------------------------
def logo():
    # Rundad kvadrat, platt: skog i kvällsljus och en älg bakifrån på stigen
    return svg(256, 256, f"""
<defs><clipPath id="c"><rect width="256" height="256" rx="48"/></clipPath></defs>
<g clip-path="url(#c)">
<rect width="256" height="256" fill="#F2B24C"/>
<circle cx="128" cy="118" r="54" fill="#FFD98A"/>
<path d="M0,150 L18,96 L36,150 L44,110 L60,150 L74,80 L92,150 L196,150 L208,90 L222,150 L232,104 L246,150 L256,120 L256,256 L0,256 Z" fill="#2E5A34"/>
<path d="M0,150 L256,150 L256,256 L0,256 Z" fill="#3E7A3E"/>
<path d="M110,150 L146,150 L210,256 L46,256 Z" fill="#C9A06A"/>
<g transform="translate(78,98) scale(0.5)">{moose("a")[moose("a").index(">") + 1:moose("a").rindex("</svg>")]}</g>
</g>
""")


def main():
    os.makedirs(OUT, exist_ok=True)
    write("moose-a.svg", moose("a"))
    write("moose-b.svg", moose("b"))
    write("moose-duck.svg", moose("duck"))
    write("stump.svg", stump())
    write("lingon.svg", lingon())
    write("chanterelle.svg", chanterelle())
    write("boots.svg", boots())
    write("wind.svg", wind())
    write("basket.svg", basket())
    for season in ("summer", "autumn", "winter"):
        write(f"branch-{season}.svg", branch(season))
        write(f"pile-{season}.svg", pile(season))
        write(f"log-{season}.svg", fallen_log(season))
        write(f"spruce-{season}.svg", spruce(season))
        write(f"pine-{season}.svg", pine(season))
        write(f"birch-{season}.svg", birch(season))
        write(f"rock-{season}.svg", rock(season))
    write("logo.svg", logo())


if __name__ == "__main__":
    main()
