// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import QtMultimedia 5.12

// Bakgrundsljud (skog eller vinterskog) och korta ljudeffekter.
// Effekterna är skapade för spelet med tools/make_sounds.py.
Item {
    id: sounds
    property bool ambienceOn: true
    property bool effectsOn: true
    property string world: "forest"            // forest eller winter
    readonly property bool active: Qt.application.state === Qt.ApplicationActive
    readonly property bool shouldPlay: ambienceOn && active && world !== ""

    Audio {
        id: ambience
        source: sounds.world !== "" ? Qt.resolvedUrl("../assets/sounds/ambience-" + sounds.world + ".ogg") : ""
        loops: Audio.Infinite
        volume: 0.4
        onSourceChanged: if (sounds.shouldPlay) play()
    }
    onShouldPlayChanged: shouldPlay ? ambience.play() : ambience.pause()
    Component.onCompleted: if (shouldPlay) ambience.play()

    readonly property var names: ["jump", "slide", "lane", "berry", "shroom", "power", "stumble", "crash", "smash"]
    property var effects: ({})
    property double lastBerry: 0

    Component {
        id: effectComp
        SoundEffect { volume: 0.7 }
    }

    function play(name) {
        if (!effectsOn || names.indexOf(name) < 0) return
        // Många bär i rad: högst ett pling per 60 ms
        if (name === "berry") {
            var now = Date.now()
            if (now - lastBerry < 60) return
            lastBerry = now
        }
        var e = effects[name]
        if (!e) {
            e = effectComp.createObject(sounds, { source: Qt.resolvedUrl("../assets/sounds/" + name + ".wav") })
            effects[name] = e
        }
        e.play()
    }

    // Läs in effekterna i förväg så att första hoppet inte hackar
    Timer {
        interval: 500; running: sounds.effectsOn
        onTriggered: {
            for (var i = 0; i < sounds.names.length; i++) {
                var n = sounds.names[i]
                if (!sounds.effects[n])
                    sounds.effects[n] = effectComp.createObject(sounds, { source: Qt.resolvedUrl("../assets/sounds/" + n + ".wav") })
            }
        }
    }
}
