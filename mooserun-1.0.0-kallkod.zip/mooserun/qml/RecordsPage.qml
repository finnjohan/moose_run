// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

Page {
    id: page
    header: PageHeader { id: header; title: root.tr("Records") }

    function dateText(ts) {
        return new Date(ts).toLocaleDateString(Qt.locale(root.lang === "sv" ? "sv_SE" : "en_GB"), Locale.ShortFormat)
    }

    Flickable {
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        contentHeight: content.height + units.gu(4)
        clip: true

        Column {
            id: content
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
            spacing: units.gu(1.5)

            // Sammanfattning i fyra rutor
            Grid {
                width: parent.width
                columns: 2
                spacing: units.gu(1)
                Repeater {
                    model: [
                        { value: root.stats.best, label: root.tr("Best score") },
                        { value: root.tr("%1 m").arg(root.stats.longest), label: root.tr("Longest run") },
                        { value: root.stats.berries, label: root.tr("Lingonberries in total") },
                        { value: root.stats.runs, label: root.tr("Runs") }
                    ]
                    Rectangle {
                        width: (content.width - units.gu(1)) / 2
                        height: units.gu(8)
                        radius: units.gu(1)
                        color: theme.palette.normal.foreground
                        Column {
                            anchors.centerIn: parent
                            Label { anchors.horizontalCenter: parent.horizontalCenter; text: modelData.value; textSize: Label.Large; font.weight: Font.Bold }
                            Label { anchors.horizontalCenter: parent.horizontalCenter; text: modelData.label; textSize: Label.Small
                                    color: theme.palette.normal.backgroundSecondaryText }
                        }
                    }
                }
            }

            Item { width: 1; height: units.gu(0.5) }
            Label { text: root.tr("Top runs"); font.weight: Font.Medium }
            Label {
                visible: root.topRuns.length === 0
                width: parent.width
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("No runs yet. Your best runs will show up here.")
            }
            Column {
                width: parent.width
                Repeater {
                    model: root.topRuns
                    ListItem {
                        width: parent.width
                        height: units.gu(6)
                        divider.visible: index < root.topRuns.length - 1
                        Label {
                            id: rank
                            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                            width: units.gu(4)
                            text: (index + 1) + "."
                            font.weight: Font.Bold
                            color: index === 0 ? "#E8862A" : theme.palette.normal.backgroundText
                        }
                        Column {
                            anchors { left: rank.right; verticalCenter: parent.verticalCenter }
                            Label { text: modelData.score; font.weight: Font.Bold }
                            Label {
                                text: root.tr("%1 m").arg(modelData.meters) + " · " + root.tr("%1 lingonberries").arg(modelData.berries)
                                textSize: Label.Small
                                color: theme.palette.normal.backgroundSecondaryText
                            }
                        }
                        Label {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            text: page.dateText(modelData.ts)
                            textSize: Label.Small
                            color: theme.palette.normal.backgroundSecondaryText
                        }
                    }
                }
            }
        }
    }
}
