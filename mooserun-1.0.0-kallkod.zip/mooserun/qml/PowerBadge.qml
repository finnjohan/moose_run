// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

// En kraftsak som är igång: bild och en stapel som krymper med tiden.
Item {
    id: badge
    property alias source: img.source
    property real remaining: 0
    property real total: 10
    visible: remaining > 0
    width: units.gu(5); height: units.gu(5.8)

    Rectangle {
        width: parent.width; height: parent.width
        radius: width / 2
        color: "#90FFFFFF"
        border.color: "#605A3A1A"; border.width: units.dp(1)
        Image {
            id: img
            anchors.centerIn: parent
            width: parent.width * 0.7; height: width
            sourceSize: Qt.size(96, 96)
            fillMode: Image.PreserveAspectFit
            // Blinkar de sista två sekunderna
            opacity: badge.remaining < 2 ? 0.5 + 0.5 * Math.abs(Math.sin(badge.remaining * 6)) : 1
        }
    }
    Rectangle {
        anchors { bottom: parent.bottom; horizontalCenter: parent.horizontalCenter }
        width: parent.width; height: units.gu(0.6); radius: height / 2
        color: "#60000000"
        Rectangle {
            width: parent.width * Math.max(0, Math.min(1, badge.remaining / badge.total))
            height: parent.height; radius: parent.radius
            color: "#FFC107"
        }
    }
}
