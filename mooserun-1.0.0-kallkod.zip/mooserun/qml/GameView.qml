// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import "Logic.js" as Logic

// Skogen i låtsas-3D. Varje punkt (x, y, z) i världen räknas om till skärmen
// med enkel perspektivprojektion: ju längre bort, desto mindre och närmare
// horisonten. Alla bilder är vanliga QML-objekt som flyttas varje bildruta.
Item {
    id: view
    clip: true

    property bool running: true
    property bool autoplay: false          // datorspelaren springer (menyn, skärmdumpar)
    property bool restartOnCrash: false    // menyn: börja om direkt efter en krock
    property int seed: -1
    property string season: "summer"       // summer, autumn, winter
    property bool night: false

    // Läget i spelet, för rubrikraden
    property int score: 0
    property int berries: 0
    property int meters: 0
    property real boots: 0
    property real wind: 0
    property real basket: 0
    property bool over: false
    property bool stumbling: false

    signal sound(string name)
    signal finished()

    // ---- Kamera och projektion ----------------------------------------------
    readonly property real camDist: 7          // kameran står 7 m bakom älgen ...
    readonly property real camH: 4.2           // ... och 4,2 m upp
    readonly property real horizon: height * 0.36
    readonly property real focal: (height * 0.85 - horizon) * camDist / camH
    readonly property real pathHalf: 1.5 * Logic.LANE_W + 0.4

    function sx(x, z) { return width / 2 + x * focal / (z + camDist) }
    function sy(y, z) { return horizon + (camH - y) * focal / (z + camDist) }
    function scaleAt(z) { return focal / (z + camDist) }

    // ---- Färger efter årstid och tid på dygnet ------------------------------
    readonly property var palette: ({
        summer: { skyTop: "#7EC3EC", skyLow: "#D6EEF8", floor: "#4E7F3A", path: "#B08A5A", track: "#C29C6A", edge: "#7A5A36", trees: "#2A4A2E" },
        autumn: { skyTop: "#94B4CE", skyLow: "#EDE4CF", floor: "#7A6A34", path: "#A07A4E", track: "#B38B5C", edge: "#6B4E2E", trees: "#5A4A26" },
        winter: { skyTop: "#A9C9E2", skyLow: "#EEF4F9", floor: "#E6ECF1", path: "#C9BBA8", track: "#D8CDBE", edge: "#9A8F80", trees: "#33493F" }
    })
    readonly property var colors: palette[season] || palette.summer

    property var game: null
    property var sprites: ({})         // objektets id → WorldSprite
    property var pool: []              // lediga WorldSprite
    property var trees: []
    property real lastTick: 0
    property real legPhase: 0

    function start() {
        game = Logic.newGame(seed >= 0 ? seed : Date.now() % 2147483647)
        for (var id in sprites) release(sprites[id])
        sprites = ({})
        over = false
        lastTick = Date.now()
        render()
    }

    function input(dir) {
        if (!game || autoplay) return
        Logic.input(game, dir)
    }

    // ---- Spelloopen ----------------------------------------------------------
    Timer {
        id: loop
        interval: 16; repeat: true
        running: view.running && view.game !== null && Qt.application.state === Qt.ApplicationActive
        onRunningChanged: view.lastTick = Date.now()
        onTriggered: view.tick()
    }

    function tick() {
        var now = Date.now()
        var dt = Math.min(0.05, (now - lastTick) / 1000)
        lastTick = now
        var g = game
        var wasOver = g.over
        // Fasta steg på högst 1/60 s
        var steps = Math.max(1, Math.ceil(dt / (1 / 60)))
        for (var i = 0; i < steps; i++) {
            if (autoplay) { var a = Logic.bot(g); if (a) Logic.input(g, a) }
            Logic.step(g, dt / steps)
        }
        for (var e = 0; e < g.events.length; e++) {
            var ev = g.events[e]
            if (ev !== "land") sound(ev)
        }
        g.events = []
        if (g.over && !wasOver) { over = true; crashTimer.restart() }
        legPhase += dt * g.speed * 0.42
        render()
    }

    Timer {
        id: crashTimer
        interval: 900
        onTriggered: {
            if (view.restartOnCrash) view.start()
            else view.finished()
        }
    }

    // ---- Himmel, mark och stig -------------------------------------------------
    Rectangle {
        anchors { left: parent.left; right: parent.right; top: parent.top }
        height: view.horizon + 2
        gradient: Gradient {
            GradientStop { position: 0; color: view.night ? (view.season === "winter" ? "#071A2B" : "#0E1A33") : view.colors.skyTop }
            GradientStop { position: 1; color: view.night ? (view.season === "winter" ? "#2A4A60" : "#3A4370") : view.colors.skyLow }
        }
    }
    Rectangle {      // sol eller måne
        x: view.width * 0.1; y: view.horizon * 0.42
        width: view.width * 0.13; height: width; radius: width / 2
        color: view.night ? "#F2EBC8" : (view.season === "winter" ? "#FFE9B0" : "#FFD95A")
    }
    Repeater {
        model: view.night ? 24 : 0
        Rectangle {
            width: 2; height: 2; radius: 1; color: "#FFFFFF"; opacity: 0.5 + (index % 3) * 0.15
            x: (index * 137) % view.width; y: (index * 53) % (view.horizon * 0.8)
        }
    }

    Canvas {
        id: ground
        anchors.fill: parent
        property var c: view.colors
        onCChanged: requestPaint()
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        onPaint: {
            var ctx = getContext("2d")
            ctx.reset()
            var h = view.horizon
            // Skogsbryn vid horisonten: taggiga grantoppar
            ctx.fillStyle = c.trees
            ctx.beginPath()
            ctx.moveTo(0, h + 1)
            var x = 0, k = 0
            while (x < width) {
                var tall = 6 + ((k * 7919) % 13) * 1.6
                ctx.lineTo(x + 5, h - tall)
                ctx.lineTo(x + 10, h - tall * 0.35)
                x += 9 + (k % 4) * 3
                k++
            }
            ctx.lineTo(width, h + 1)
            ctx.closePath()
            ctx.fill()
            // Skogsmark
            ctx.fillStyle = c.floor
            ctx.fillRect(0, h, width, height - h)
            // Stigen och de tre trampade spåren
            function strip(x0, x1, color) {
                var zf = 400, zn = -view.camDist + 0.6
                ctx.fillStyle = color
                ctx.beginPath()
                ctx.moveTo(view.sx(x0, zf), view.sy(0, zf))
                ctx.lineTo(view.sx(x1, zf), view.sy(0, zf))
                ctx.lineTo(view.sx(x1, zn), view.sy(0, zn))
                ctx.lineTo(view.sx(x0, zn), view.sy(0, zn))
                ctx.closePath()
                ctx.fill()
            }
            strip(-view.pathHalf - 0.15, view.pathHalf + 0.15, c.edge)
            strip(-view.pathHalf, view.pathHalf, c.path)
            for (var l = -1; l <= 1; l++)
                strip(l * Logic.LANE_W - 0.45, l * Logic.LANE_W + 0.45, c.track)
        }
    }

    // Tvärgående band som glider förbi och visar farten
    Item {
        id: bands
        anchors.fill: parent
        Repeater {
            id: bandRep
            model: 20
            Rectangle {
                width: view.width
                color: "#000000"
                opacity: view.season === "winter" ? 0.045 : 0.07
            }
        }
    }

    // ---- Allt i skogen ---------------------------------------------------------
    Item {
        id: world
        anchors.fill: parent

        Rectangle {        // skugga under älgen
            id: shadow
            color: "#000000"
            opacity: 0.25
            z: -0.3
        }
        Image {
            id: moose
            z: 0
            smooth: true
            sourceSize: Qt.size(400, 520)
            source: "../assets/moose-a.svg"
        }
    }

    // Kvällsljus
    Rectangle {
        anchors.fill: parent
        visible: view.night
        color: view.season === "winter" ? "#0A1E3A" : "#1A1E46"
        opacity: 0.38
    }
    // Röd blixt vid krock, gul vid snubbel
    Rectangle {
        id: flash
        anchors.fill: parent
        color: view.over ? "#C62828" : "#FFC107"
        opacity: 0
    }

    Component { id: spriteComp; WorldSprite {} }

    function info(type) {
        // bredd, höjd (m), bild, bildens upplösning
        switch (type) {
        case "stump":  return { w: 1.3, h: 0.85, src: "stump.svg", res: 256 }
        case "branch": return { w: 1.6, h: 2.1, src: "branch-" + season + ".svg", res: 320 }
        case "pile":   return { w: 1.5, h: 2.4, src: "pile-" + season + ".svg", res: 320 }
        case "log":    return { w: 5.4, h: 0.8, src: "log-" + season + ".svg", res: 640 }
        case "berry":  return { w: 0.45, h: 0.45, src: "lingon.svg", res: 96 }
        case "shroom": return { w: 0.6, h: 0.6, src: "chanterelle.svg", res: 128 }
        case "boots":  return { w: 0.9, h: 0.65, src: "boots.svg", res: 128, glow: true }
        case "wind":   return { w: 0.75, h: 0.75, src: "wind.svg", res: 128, glow: true }
        case "basket": return { w: 0.8, h: 0.75, src: "basket.svg", res: 128, glow: true }
        }
        return { w: 1, h: 1, src: "stump.svg", res: 64 }
    }

    function obtain(o) {
        var inf = info(o.type)
        var sp = pool.length ? pool.pop() : spriteComp.createObject(world)
        sp.objectId = o.id
        sp.worldW = inf.w; sp.worldH = inf.h
        var ratio = inf.w / inf.h
        sp.sourceSize = ratio >= 1 ? Qt.size(inf.res, Math.round(inf.res / ratio)) : Qt.size(Math.round(inf.res * ratio), inf.res)
        sp.source = "../assets/" + inf.src
        sp.glow = !!inf.glow
        sp.visible = true
        return sp
    }

    function release(sp) {
        sp.visible = false
        sp.objectId = -1
        pool.push(sp)
    }

    function place(item, x, y, z, w, h) {
        var k = scaleAt(z)
        item.width = w * k
        item.height = h * k
        item.x = sx(x, z) - item.width / 2
        item.y = sy(y, z) - item.height
        item.z = -z
        item.opacity = Math.max(0, Math.min(1, (Logic.VIEW - z) / 20))
    }

    // ---- Rita en bildruta --------------------------------------------------------
    function render() {
        var g = game
        if (!g) return
        var nearZ = -camDist + 1.2

        // Band på marken var 6:e meter
        for (var b = 0; b < bandRep.count; b++) {
            var r = bandRep.itemAt(b)
            var z0 = b * 6 - (g.dist % 6) - 4
            if (z0 < nearZ) { r.visible = false; continue }
            r.visible = true
            var top = sy(0, z0 + 1.6), bot = sy(0, z0)
            r.y = top; r.height = Math.max(1, bot - top)
        }

        // Träd längs stigen
        for (var i = 0; i < trees.length; i++) {
            var t = trees[i]
            var tz = t.pz - g.dist
            if (tz < nearZ) {
                t.pz += Logic.VIEW + 12
                tz = t.pz - g.dist
                t.worldX = (Math.random() < 0.5 ? -1 : 1) * (pathHalf + 0.9 + Math.pow(Math.random(), 1.6) * 10)
            }
            place(t, t.worldX, 0, tz, t.worldW, t.worldH)
            t.visible = tz < Logic.VIEW
        }

        // Hinder, bär och kraftsaker
        var seen = {}
        for (var j = 0; j < g.objects.length; j++) {
            var o = g.objects[j]
            var oz = o.pz - g.dist
            if (o.gone || (o.taken && Logic.OBSTACLES[o.type]) || oz < nearZ || oz > Logic.VIEW) continue
            seen[o.id] = true
            var sp = sprites[o.id]
            if (!sp) { sp = obtain(o); sprites[o.id] = sp }
            var ox = Logic.OBSTACLES[o.type] && Logic.OBSTACLES[o.type].all ? 0 : o.lane * Logic.LANE_W
            var oy = o.y
            if (!Logic.OBSTACLES[o.type]) oy += 0.08 + 0.08 * Math.sin(g.t * 5 + o.id)
            place(sp, ox, oy, oz, sp.worldW, sp.worldH)
        }
        for (var id in sprites) {
            if (!seen[id]) { release(sprites[id]); delete sprites[id] }
        }

        // Älgen
        var mw = 1.75, mh = 2.27
        var frame = g.slide > 0 ? "duck" : (g.y > 0.05 ? "a" : (Math.floor(legPhase) % 2 ? "b" : "a"))
        moose.source = "../assets/moose-" + frame + ".svg"
        var bob = (g.y <= 0.001 && g.slide <= 0 && !g.over) ? Math.abs(Math.sin(legPhase * Math.PI)) * 0.07 : 0
        place(moose, g.x, g.y + bob, 0, mw, mh)
        moose.z = 0
        moose.opacity = g.wind > 0 ? 0.85 + 0.15 * Math.sin(g.t * 30) : 1
        var shake = g.over && g.overT < 0.5 ? Math.sin(g.overT * 60) * 0.08 * (1 - g.overT * 2) : 0
        var wobble = g.stumbleT > Logic.STUMBLE_T - 0.4 ? Math.sin(g.t * 40) * 8 : 0
        moose.rotation = g.over ? 10 * Math.min(1, g.overT * 6) : wobble
        moose.x += shake * scaleAt(0)
        var k0 = scaleAt(0)
        var sw = 1.2 * k0 * Math.max(0.5, 1 - g.y * 0.15)
        shadow.width = sw; shadow.height = sw * 0.22; shadow.radius = shadow.height / 2
        shadow.x = sx(g.x, 0) - sw / 2
        shadow.y = sy(0, 0) - shadow.height / 2

        // Blixt
        if (g.over) flash.opacity = Math.max(0, 0.35 - g.overT * 0.8)
        else if (g.stumbleT > Logic.STUMBLE_T - 0.3) flash.opacity = 0.18
        else flash.opacity = 0

        score = g.score
        berries = g.berries
        meters = Math.floor(g.dist)
        boots = g.boots; wind = g.wind; basket = g.basket
        stumbling = g.stumbleT > 0
    }

    // ---- Träden skapas en gång och återanvänds ----------------------------------
    function makeTrees() {
        for (var i = 0; i < trees.length; i++) trees[i].destroy()
        var list = []
        var kinds = [
            { src: "spruce", w: 3.2, h: 8.0, res: 300 }, { src: "spruce", w: 3.6, h: 9.0, res: 300 },
            { src: "pine", w: 3.6, h: 9.0, res: 300 }, { src: "birch", w: 3.0, h: 7.5, res: 300 },
            { src: "rock", w: 1.6, h: 1.0, res: 128 }
        ]
        for (var n = 0; n < 56; n++) {
            var kd = kinds[n % kinds.length]
            var t = spriteComp.createObject(world)
            t.worldW = kd.w; t.worldH = kd.h
            t.sourceSize = Qt.size(Math.round(kd.res * kd.w / kd.h), kd.res)
            t.source = "../assets/" + kd.src + "-" + season + ".svg"
            t.visible = true
            t.kind = kd.src
            t.pz = (n / 56) * (Logic.VIEW + 12) - camDist + 1.5
            t.worldX = (n % 2 ? -1 : 1) * (pathHalf + 1.2 + ((n * 37) % 90) / 10)
            list.push(t)
        }
        trees = list
    }

    onSeasonChanged: {
        for (var i = 0; i < trees.length; i++) trees[i].source = "../assets/" + trees[i].kind + "-" + season + ".svg"
        for (var id in sprites) sprites[id].visible = false
        for (var k in sprites) release(sprites[k])
        sprites = ({})
        render()
    }

    Component.onCompleted: makeTrees()

    // ---- Svep och tangenter -----------------------------------------------------
    MouseArea {
        anchors.fill: parent
        enabled: !view.autoplay
        property real px: 0
        property real py: 0
        property bool fired: false
        onPressed: { px = mouse.x; py = mouse.y; fired = false; view.forceActiveFocus() }
        onPositionChanged: {
            if (fired) return
            var dx = mouse.x - px, dy = mouse.y - py
            var th = units.gu(2.5)
            if (Math.abs(dx) < th && Math.abs(dy) < th) return
            fired = true
            if (Math.abs(dx) > Math.abs(dy)) view.input(dx < 0 ? "left" : "right")
            else view.input(dy < 0 ? "up" : "down")
        }
    }
    focus: true
    Keys.onPressed: {
        if (event.key === Qt.Key_Left || event.key === Qt.Key_A) view.input("left")
        else if (event.key === Qt.Key_Right || event.key === Qt.Key_D) view.input("right")
        else if (event.key === Qt.Key_Up || event.key === Qt.Key_W || event.key === Qt.Key_Space) view.input("up")
        else if (event.key === Qt.Key_Down || event.key === Qt.Key_S) view.input("down")
        else return
        event.accepted = true
    }
}
