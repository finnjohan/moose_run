.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Spelreglerna för Moose Run, utan QML-beroenden (testas med node).
// Världen: tre filer (lane −1, 0, 1) bredvid varandra. Älgen står still på
// z = 0 och skogen rör sig mot den; varje föremål har en absolut position pz
// längs stigen och avståndet framåt är pz − dist. Enheten är meter.

var LANE_W = 1.6            // filbredd
var GRAVITY = 30
var JUMP_V = 10.2           // ger ca 1,7 m hopphöjd
var BOOT_JUMP_V = 15.0      // med stövlar: ca 3,75 m, högt nog över vedtravar
var DROP_V = -22            // svep nedåt i luften: snabb landning
var SLIDE_T = 0.7           // så länge älgen duckar
var LANE_T = 0.13           // tid för ett filbyte
var HALF_D = 0.45           // älgens halva längd (z)
var STAND_H = 2.0           // älgens höjd (utan horn)
var DUCK_H = 1.0
var STUMBLE_T = 5           // två snubblingar inom så här lång tid = slut
var START_SPEED = 11
var MAX_SPEED = 30
var VIEW = 115              // hur långt fram skogen byggs

// kind: low = hoppa över, high = ducka under, block = byt fil
var OBSTACLES = {
    stump:  { kind: "low",   lo: 0,    h: 0.85, d: 0.8 },
    log:    { kind: "low",   lo: 0,    h: 0.8,  d: 0.9, all: true },   // omkullfallen gran över hela stigen
    branch: { kind: "high",  lo: 1.15, h: 2.1,  d: 0.5 },
    pile:   { kind: "block", lo: 0,    h: 2.4,  d: 2.2 }
}
var POWERUPS = {
    boots:  { time: 10 },    // högre hopp
    wind:   { time: 5 },     // vindpust: snabbare och går inte att stoppa
    basket: { time: 10 }     // bärkorg: plockar bär i alla filer
}
var SCORE_BERRY = 5
var SCORE_SHROOM = 50

// ---- Slump med frö (mulberry32), så att samma frö ger samma skog ----------
function makeRand(seed) {
    var a = (seed >>> 0) || 1
    return function () {
        a = (a + 0x6D2B79F5) >>> 0
        var t = a
        t = Math.imul(t ^ (t >>> 15), t | 1)
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296
    }
}

function newGame(seed) {
    var s = {
        rand: makeRand(seed === undefined ? Date.now() : seed),
        t: 0, dist: 0, speed: START_SPEED,
        lane: 0, fromLane: 0, x: 0,
        y: 0, vy: 0, slide: 0, slideOnLand: false,
        stumbleT: 0, graceT: 0,
        boots: 0, wind: 0, basket: 0,
        berries: 0, shrooms: 0, score: 0,
        over: false, overT: 0,
        objects: [], nextId: 1,
        nextRowZ: 40, lastRowEnd: 0, nextPowerZ: 350, nextShroomZ: 250,
        events: []
    }
    fill(s)
    return s
}

function speedAt(dist) {
    return START_SPEED + (MAX_SPEED - START_SPEED) * (1 - Math.exp(-dist / 2600))
}

// 0 i början, närmar sig 1 efter några kilometer
function difficulty(dist) {
    return Math.min(1, dist / 2500)
}

function computeScore(s) {
    return Math.floor(s.dist) + s.berries * SCORE_BERRY + s.shrooms * SCORE_SHROOM
}

// ---- Styrning ---------------------------------------------------------------
function input(s, dir) {
    if (s.over) return
    if (dir === "left" || dir === "right") {
        var target = s.lane + (dir === "left" ? -1 : 1)
        if (target < -1 || target > 1) return
        s.fromLane = s.lane
        s.lane = target
        s.events.push("lane")
    } else if (dir === "up") {
        if (s.y <= 0.001) {
            s.vy = s.boots > 0 ? BOOT_JUMP_V : JUMP_V
            s.slide = 0
            s.slideOnLand = false
            s.events.push("jump")
        }
    } else if (dir === "down") {
        if (s.y > 0.001) {
            s.vy = Math.min(s.vy, DROP_V)
            s.slideOnLand = true
        } else {
            s.slide = SLIDE_T
            s.events.push("slide")
        }
    }
}

function onGround(s) { return s.y <= 0.001 }
function height(s) { return s.slide > 0 ? DUCK_H : STAND_H }
function currentLane(s) { return Math.max(-1, Math.min(1, Math.round(s.x / LANE_W))) }

// Krockar älgen med hindret o i höjdled?
function blocksVertically(s, o) {
    var t = OBSTACLES[o.type]
    var bottom = s.y, top = s.y + height(s)
    return top > t.lo + 0.02 && bottom < t.h - 0.02
}

// ---- Ett tidssteg -----------------------------------------------------------
function step(s, dt) {
    s.t += dt
    if (s.over) { s.overT += dt; return }

    s.speed = speedAt(s.dist) * (s.wind > 0 ? 1.35 : 1)
    s.dist += s.speed * dt

    // Sidled: glid mot målfilen
    var tx = s.lane * LANE_W
    var vx = LANE_W / LANE_T
    if (Math.abs(tx - s.x) <= vx * dt) s.x = tx
    else s.x += (tx > s.x ? 1 : -1) * vx * dt

    // Höjdled
    if (s.y > 0 || s.vy > 0) {
        s.vy -= GRAVITY * dt
        s.y += s.vy * dt
        if (s.y <= 0) {
            s.y = 0; s.vy = 0
            s.events.push("land")
            if (s.slideOnLand) { s.slide = SLIDE_T; s.slideOnLand = false; s.events.push("slide") }
        }
    }
    if (s.slide > 0) s.slide = Math.max(0, s.slide - dt)

    s.stumbleT = Math.max(0, s.stumbleT - dt)
    s.graceT = Math.max(0, s.graceT - dt)
    s.boots = Math.max(0, s.boots - dt)
    s.wind = Math.max(0, s.wind - dt)
    s.basket = Math.max(0, s.basket - dt)

    collide(s)
    s.score = computeScore(s)

    // Ta bort det som passerat kameran och bygg mer skog framåt
    var keep = []
    for (var i = 0; i < s.objects.length; i++)
        if (s.objects[i].pz - s.dist > -10 && !s.objects[i].gone) keep.push(s.objects[i])
    s.objects = keep
    fill(s)
}

function collide(s) {
    var cl = currentLane(s)
    var moving = Math.abs(s.x - s.lane * LANE_W) > 0.01
    for (var i = 0; i < s.objects.length; i++) {
        var o = s.objects[i]
        if (o.taken) continue
        var z = o.pz - s.dist
        var ob = OBSTACLES[o.type]
        if (ob) {
            if (z > HALF_D || z + ob.d < -HALF_D) continue
            if (!ob.all && o.lane !== cl) continue
            if (!blocksVertically(s, o)) continue
            if (s.wind > 0) { o.taken = true; s.events.push("smash"); continue }
            if (s.graceT > 0 && !ob.all && o.lane !== s.lane) continue
            // Älgen var på väg in i en fil där hindret redan står: studsa tillbaka
            if (moving && !ob.all && o.lane === s.lane && s.lane !== s.fromLane) {
                s.lane = s.fromLane
                s.fromLane = cl
                s.graceT = 0.35
                if (s.stumbleT > 0) { crash(s, o); return }
                s.stumbleT = STUMBLE_T
                s.events.push("stumble")
                continue
            }
            crash(s, o)
            return
        }
        // Saker att plocka
        if (Math.abs(z) > 0.9) continue
        var magnet = s.basket > 0 && o.type === "berry"
        if (!magnet && o.lane !== cl) continue
        var oy = o.y || 0
        var mid = s.y + height(s) * 0.5
        if (!magnet && Math.abs(oy + 0.3 - mid) > height(s) * 0.5 + 0.5) continue
        o.taken = true
        o.gone = true
        if (o.type === "berry") { s.berries++; s.events.push("berry") }
        else if (o.type === "shroom") { s.shrooms++; s.events.push("shroom") }
        else { s[o.type] = POWERUPS[o.type].time; s.events.push("power") }
    }
}

function crash(s, o) {
    s.over = true
    s.overT = 0
    s.crashType = o ? o.type : ""
    s.events.push("crash")
}

// ---- Skogen byggs rad för rad -----------------------------------------------
function add(s, type, lane, pz, y) {
    var o = { id: s.nextId++, type: type, lane: lane, pz: pz, y: y || 0, taken: false }
    s.objects.push(o)
    return o
}

function pick(s, weights) {
    var sum = 0, k
    for (k in weights) sum += weights[k]
    var r = s.rand() * sum
    for (k in weights) { r -= weights[k]; if (r <= 0) return k }
    return k
}

function shuffle(s, arr) {
    for (var i = arr.length - 1; i > 0; i--) {
        var j = Math.floor(s.rand() * (i + 1))
        var t = arr[i]; arr[i] = arr[j]; arr[j] = t
    }
    return arr
}

function fill(s) {
    while (s.nextRowZ < s.dist + VIEW) {
        var z = s.nextRowZ
        var v = speedAt(z)
        var gap = spawnRow(s, z)
        // Avståndet till nästa rad: minst så att man hinner reagera
        s.nextRowZ = z + gap + v * (1.1 + s.rand() * 0.7 - 0.2 * difficulty(z))
    }
}

// Lägger ut en rad hinder på z och returnerar hur djup raden är.
function spawnRow(s, z) {
    var d = difficulty(z)
    var lanes = shuffle(s, [-1, 0, 1])
    var pattern = pick(s, { single: 3 - 1.8 * d, double: 1.2 + 1.2 * d, triple: 0.2 + 1.6 * d, log: 0.5, rest: 0.45 - 0.3 * d })
    var types = { "-1": "", "0": "", "1": "" }
    var depth = 0

    function obstacleType(allowPile) {
        return pick(s, allowPile ? { stump: 1, branch: 1, pile: 1.1 } : { stump: 1, branch: 1 })
    }

    if (pattern === "log") {
        add(s, "log", 0, z)
        depth = OBSTACLES.log.d
        if (s.rand() < 0.6) berryArc(s, lanes[0], z, OBSTACLES.log.d)
    } else if (pattern !== "rest") {
        var n = pattern === "single" ? 1 : pattern === "double" ? 2 : 3
        var piles = 0
        for (var i = 0; i < n; i++) {
            // Högst två vedtravar i samma rad: en fil måste alltid gå att ta sig igenom
            var t = obstacleType(piles < 2 && !(n === 3 && i === 2 && piles === 2))
            if (t === "pile") piles++
            types[lanes[i]] = t
            add(s, t, lanes[i], z)
            depth = Math.max(depth, OBSTACLES[t].d)
        }
        // Bär: en båge över en stubbe eller en rad fram mot en fri fil
        var free = lanes.filter(function (l) { return types[l] === "" })
        var stumps = lanes.filter(function (l) { return types[l] === "stump" })
        if (stumps.length && s.rand() < 0.35) berryArc(s, stumps[0], z, OBSTACLES.stump.d)
        else if (free.length && s.rand() < 0.75) berryLine(s, free[0], s.lastRowEnd + 3, z + 3)
        else if (!free.length && s.rand() < 0.5) {
            var easy = lanes.filter(function (l) { return types[l] !== "pile" })
            berryLine(s, easy[0], s.lastRowEnd + 3, z - 4)
        }
    } else {
        berryLine(s, lanes[0], s.lastRowEnd + 3, z + 14)
        depth = 14
    }

    // Kraftsaker och kantareller hamnar i en fil som är fri på den här raden
    var freeLane = [-1, 0, 1].filter(function (l) { return types[l] === "" && pattern !== "log" })
    var mid = (s.lastRowEnd + z) / 2
    if (z > s.nextPowerZ && freeLane.length && z - s.lastRowEnd > 10) {
        add(s, pick(s, { boots: 1, wind: 1, basket: 1 }), freeLane[0], mid, 0.4)
        s.nextPowerZ = z + 450 + s.rand() * 350
    } else if (z > s.nextShroomZ && freeLane.length && z - s.lastRowEnd > 10) {
        add(s, "shroom", freeLane[freeLane.length - 1], mid, 0.1)
        s.nextShroomZ = z + 250 + s.rand() * 300
    }

    s.lastRowEnd = z + depth
    return depth
}

function berryLine(s, lane, from, to) {
    var n = Math.min(8, Math.floor((to - from) / 2.2))
    for (var i = 0; i < n; i++) add(s, "berry", lane, from + i * 2.2, 0.15)
}

// Bär i en båge som följer ett hopp över hindret
function berryArc(s, lane, z, d) {
    var v = speedAt(z)
    var air = 2 * JUMP_V / GRAVITY
    var start = z + d / 2 - v * air / 2
    for (var i = 0; i < 7; i++) {
        var t = air * (i + 0.5) / 7
        add(s, "berry", lane, start + v * t, Math.max(0.15, JUMP_V * t - GRAVITY * t * t / 2 + 0.15))
    }
}

// ---- Datorspelare: används av testerna och för skärmdumpar (--autoplay) ------
// Väljer fil för närmaste rad med hinder och hoppar eller duckar i tid.
function bot(s) {
    if (s.over) return ""
    var near = []
    for (var i = 0; i < s.objects.length; i++) {
        var o = s.objects[i]
        var ob = OBSTACLES[o.type]
        if (!ob || o.taken) continue
        var z = o.pz - s.dist
        if (z + ob.d < -HALF_D) continue
        near.push({ o: o, z: z, ob: ob })
    }
    if (!near.length) return s.lane !== 0 && Math.abs(s.x - s.lane * LANE_W) < 0.05 ? (s.lane > 0 ? "left" : "right") : ""
    near.sort(function (a, b) { return a.z - b.z })
    var rowZ = near[0].z
    var row = near.filter(function (n) { return n.z - rowZ < 0.5 })

    function kindIn(l) {
        for (var k = 0; k < row.length; k++)
            if (row[k].ob.all || row[k].o.lane === l) return row[k].ob.kind
        return ""
    }
    // Bästa fil: fri, annars hopp/ducka, aldrig vedtrave. Nära först.
    var best = s.lane, bestCost = 1e9
    for (var l = -1; l <= 1; l++) {
        var kind = kindIn(l)
        if (kind === "block") continue
        var cost = Math.abs(l - s.lane) * 2 + (kind === "" ? 0 : 3) + Math.abs(l) * 0.1
        // Ett filbyte genom en vedtrave som redan är i höjd med älgen går inte
        if (l !== s.lane && rowZ < s.speed * 0.25 + 1) {
            var mid = s.lane + (l > s.lane ? 1 : -1)
            if (kindIn(mid) === "block" || kindIn(l) === "block") cost += 100
        }
        if (cost < bestCost) { bestCost = cost; best = l }
    }
    var settled = Math.abs(s.x - s.lane * LANE_W) < 0.05
    if (best !== s.lane && settled) return best < s.lane ? "left" : "right"

    var kindHere = kindIn(currentLane(s))
    var front = rowZ - HALF_D
    if (kindHere === "low" && onGround(s) && front < s.speed * 0.2 + 0.3 && front > -0.3) return "up"
    if (kindHere === "high" && s.slide < 0.25 && front < s.speed * 0.15 + 0.4 && front > -0.6) {
        return onGround(s) ? "down" : (s.vy < 0 ? "down" : "")
    }
    return ""
}
