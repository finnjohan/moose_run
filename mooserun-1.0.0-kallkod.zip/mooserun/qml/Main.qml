// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Storage.js" as Storage
import "I18n.js" as I18n

MainView {
    id: root
    objectName: "mainView"
    applicationName: "mooserun.johanfinn"
    automaticOrientation: false

    width: units.gu(argValue("width") !== "" ? parseInt(argValue("width"), 10) : 45)
    height: units.gu(argValue("height") !== "" ? parseInt(argValue("height"), 10) : 75)

    readonly property string version: "1.0.0"
    readonly property bool isDark: theme.palette.normal.background.hslLightness < 0.5

    // ---- Kommandoradsflaggor för test och skärmdumpar ---------------------
    // --demo (egen databas med några rundor)  --lang=sv|en  --theme=light|dark
    // --season=summer|autumn|winter  --page=game|settings|records
    // --autoplay (datorspelaren springer)  --seed=<n>  --width=<gu>  --height=<gu>  --mute
    function argValue(name) {
        var args = Qt.application.arguments
        for (var i = 0; i < args.length; i++) {
            if (args[i] === "--" + name) return "1"
            if (args[i].indexOf("--" + name + "=") === 0) return args[i].substring(name.length + 3)
        }
        return ""
    }
    readonly property bool demo: argValue("demo") !== ""
    readonly property bool autoplay: argValue("autoplay") !== ""
    readonly property int seed: argValue("seed") !== "" ? parseInt(argValue("seed"), 10) : -1

    // ---- Inställningar --------------------------------------------------
    property string themeSetting: "auto"
    property string langSetting: "auto"
    property string seasonSetting: "auto"
    property bool ambienceOn: true
    property bool effectsOn: true
    readonly property string lang: langSetting === "auto" ? I18n.systemLanguage(Qt.locale().name) : langSetting
    readonly property string season: seasonSetting !== "auto" ? seasonSetting : seasonOf(new Date())

    // Vinter december–mars, höst september–november, annars sommar
    function seasonOf(d) {
        var m = d.getMonth() + 1
        return (m === 12 || m <= 3) ? "winter" : (m >= 9 ? "autumn" : "summer")
    }

    function tr(s) { return I18n.tr(s, lang) }

    function setTheme(value) { themeSetting = value; Storage.setSetting("theme", value); applyTheme() }
    function setLanguage(value) { langSetting = value; Storage.setSetting("language", value) }
    function setSeason(value) { seasonSetting = value; Storage.setSetting("season", value) }
    function setAmbience(on) { ambienceOn = on; Storage.setSetting("ambience", on ? "1" : "0") }
    function setEffects(on) { effectsOn = on; Storage.setSetting("effects", on ? "1" : "0") }
    function playSound(name) { sounds.play(name) }

    function applyTheme() {
        if (themeSetting === "dark") theme.name = "Lomiri.Components.Themes.SuruDark"
        else if (themeSetting === "light") theme.name = "Lomiri.Components.Themes.Ambiance"
        else theme.name = ""
    }

    // ---- Rekord ---------------------------------------------------------
    property var stats: ({ best: 0, longest: 0, berries: 0, runs: 0 })
    property var topRuns: []
    function reloadStats() { stats = Storage.stats(); topRuns = Storage.topRuns(10) }
    function saveRun(score, meters, berries) { Storage.saveRun(score, meters, berries); reloadStats() }
    function resetRuns() { Storage.resetRuns(); reloadStats() }

    function play() { stack.push(Qt.resolvedUrl("GamePage.qml")) }

    Component.onCompleted: {
        if (demo) {
            Storage.useDatabase("mooserun-demo")
            Storage.resetRuns()
            var demoRuns = [[4210, 3120, 210], [3385, 2540, 165], [2950, 2230, 140], [2215, 1700, 99], [1840, 1390, 86], [960, 760, 38]]
            for (var i = 0; i < demoRuns.length; i++)
                Storage.saveRun(demoRuns[i][0], demoRuns[i][1], demoRuns[i][2], Date.now() - (i + 1) * 86400000 * 1.7)
        }
        langSetting = argValue("lang") !== "" ? argValue("lang") : Storage.setting("language", "auto")
        themeSetting = argValue("theme") !== "" ? argValue("theme") : Storage.setting("theme", "auto")
        seasonSetting = argValue("season") !== "" ? argValue("season") : Storage.setting("season", "auto")
        applyTheme()
        var mute = argValue("mute") !== ""
        ambienceOn = !mute && Storage.setting("ambience", "1") === "1"
        effectsOn = !mute && Storage.setting("effects", "1") === "1"
        reloadStats()
        stack.push(Qt.resolvedUrl("MenuPage.qml"))
        var page = argValue("page")
        if (page === "settings") stack.push(Qt.resolvedUrl("SettingsPage.qml"))
        else if (page === "records") stack.push(Qt.resolvedUrl("RecordsPage.qml"))
        else if (page === "game") play()
    }

    PageStack { id: stack }

    Sounds {
        id: sounds
        ambienceOn: root.ambienceOn
        effectsOn: root.effectsOn
        world: root.season === "winter" ? "winter" : "forest"
    }
}
