.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
.import QtQuick.LocalStorage 2.0 as Sql

var _db = null
var _name = "mooserun"

function useDatabase(name) { _name = name; _db = null }

function db() {
    if (_db) return _db
    _db = Sql.LocalStorage.openDatabaseSync(_name, "1.0", "Moose Run", 1000000)
    _db.transaction(function (tx) {
        tx.executeSql("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
        tx.executeSql("CREATE TABLE IF NOT EXISTS runs (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, " +
                      "score INTEGER NOT NULL, meters INTEGER NOT NULL, berries INTEGER NOT NULL)")
    })
    return _db
}

function setting(key, fallback) {
    var v = fallback
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT value FROM settings WHERE key = ?", [key])
        if (rs.rows.length > 0 && rs.rows.item(0).value !== null) v = rs.rows.item(0).value
    })
    return v
}

function setSetting(key, value) {
    db().transaction(function (tx) {
        tx.executeSql("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", [key, String(value)])
    })
}

function saveRun(score, meters, berries, ts) {
    db().transaction(function (tx) {
        tx.executeSql("INSERT INTO runs (ts, score, meters, berries) VALUES (?, ?, ?, ?)",
                      [ts || Date.now(), score, meters, berries])
    })
}

// { best, longest, berries (totalt), runs (antal) }
function stats() {
    var out = { best: 0, longest: 0, berries: 0, runs: 0 }
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT MAX(score) AS best, MAX(meters) AS longest, SUM(berries) AS berries, COUNT(*) AS runs FROM runs")
        if (rs.rows.length > 0) {
            var r = rs.rows.item(0)
            out.best = r.best || 0
            out.longest = r.longest || 0
            out.berries = r.berries || 0
            out.runs = r.runs || 0
        }
    })
    return out
}

// De bästa rundorna, högst n stycken
function topRuns(n) {
    var out = []
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT * FROM runs ORDER BY score DESC, ts ASC LIMIT ?", [n])
        for (var i = 0; i < rs.rows.length; i++) out.push(rs.rows.item(i))
    })
    return out
}

function resetRuns() {
    db().transaction(function (tx) { tx.executeSql("DELETE FROM runs") })
}
