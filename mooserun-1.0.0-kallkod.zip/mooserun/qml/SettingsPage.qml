// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import Lomiri.Components.Popups 1.3
import "I18n.js" as I18n

Page {
    id: page
    readonly property var themeValues: ["auto", "light", "dark"]
    readonly property var seasonValues: ["auto", "summer", "autumn", "winter"]
    readonly property var langValues: ["auto"].concat(I18n.languages.map(function (l) { return l.code }))

    header: PageHeader { id: header; title: root.tr("Settings") }

    Flickable {
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        contentHeight: content.height + units.gu(4)
        clip: true

        Column {
            id: content
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
            spacing: units.gu(1.5)

            Label { text: root.tr("Theme"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                expanded: true
                model: [root.tr("Automatic"), root.tr("Light (day)"), root.tr("Dark (evening)")]
                selectedIndex: Math.max(0, page.themeValues.indexOf(root.themeSetting))
                onDelegateClicked: root.setTheme(page.themeValues[index])
            }
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Season"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                expanded: true
                model: [root.tr("Automatic (follows the calendar)"), root.tr("Summer"), root.tr("Autumn"), root.tr("Winter")]
                selectedIndex: Math.max(0, page.seasonValues.indexOf(root.seasonSetting))
                onDelegateClicked: root.setSeason(page.seasonValues[index])
            }
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Language"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                expanded: true
                model: [root.tr("Automatic (system language)")].concat(I18n.languages.map(function (l) { return l.name }))
                selectedIndex: Math.max(0, page.langValues.indexOf(root.langSetting))
                onDelegateClicked: root.setLanguage(page.langValues[index])
            }
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Sound"); font.weight: Font.Medium }
            Item {
                width: parent.width; height: units.gu(5)
                Label { anchors { left: parent.left; right: ambSwitch.left; rightMargin: units.gu(1); verticalCenter: parent.verticalCenter }
                        text: root.tr("Background sounds"); wrapMode: Text.WordWrap }
                Switch { id: ambSwitch; anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                         checked: root.ambienceOn; onClicked: root.setAmbience(checked) }
            }
            Item {
                width: parent.width; height: units.gu(5)
                Label { anchors { left: parent.left; right: fxSwitch.left; rightMargin: units.gu(1); verticalCenter: parent.verticalCenter }
                        text: root.tr("Sound effects"); wrapMode: Text.WordWrap }
                Switch { id: fxSwitch; anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                         checked: root.effectsOn; onClicked: root.setEffects(checked) }
            }
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Records"); font.weight: Font.Medium }
            Button {
                text: root.tr("Clear records")
                onClicked: PopupUtils.open(resetDialog, page)
            }

            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("How to play"); font.weight: Font.Medium }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Swipe left or right to change path, up to jump over stumps and fallen trees, and down to duck under branches. You can't get past a woodpile – change path! Bumping into something from the side makes the moose stumble; stumble twice in a row and the run is over.")
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Rubber boots let you jump higher, a gust of wind carries you through everything, and the berry basket picks berries from all three paths.")
            }

            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("About"); font.weight: Font.Medium }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Help the moose run through the Swedish forest. An original game in the endless runner genre – all characters, graphics and sounds are made for this game.")
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("The background sounds come from Kottslungan by the same author.")
            }
            Label {
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Version %1").arg(root.version) + " · © 2026 Johan Finn · GPLv3"
            }
        }
    }

    Component {
        id: resetDialog
        Dialog {
            id: dlg
            title: root.tr("Clear records?")
            text: root.tr("All saved runs and best scores will be deleted.")
            Button {
                text: root.tr("Clear")
                color: theme.palette.normal.negative
                onClicked: { root.resetRuns(); PopupUtils.close(dlg) }
            }
            Button { text: root.tr("Cancel"); onClicked: PopupUtils.close(dlg) }
        }
    }
}
