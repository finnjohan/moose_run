.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

var languages = [
    { code: "en", name: "English" },
    { code: "sv", name: "Svenska" }
]

var sv = {
    // Meny
    "Run through the forest and pick lingonberries": "Spring genom skogen och plocka lingon",
    "Run!": "Spring!",
    "Best: %1": "Rekord: %1",
    "Settings": "Inställningar",

    // Spelet
    "%1 m": "%1 m",
    "Swipe left or right to change path": "Svep åt vänster eller höger för att byta stig",
    "Swipe up to jump over stumps": "Svep uppåt för att hoppa över stubbar",
    "Swipe down to duck under branches": "Svep nedåt för att ducka under grenar",
    "Careful!": "Akta!",
    "Paused": "Paus",
    "Continue": "Fortsätt",
    "Quit run": "Avsluta rundan",
    "New record!": "Nytt rekord!",
    "The moose tripped!": "Älgen snubblade!",
    "metres": "meter",
    "lingonberries": "lingon",
    "Menu": "Meny",
    "Run again": "Spring igen",

    // Rekord
    "Records": "Rekord",
    "Best score": "Bästa poäng",
    "Longest run": "Längsta rundan",
    "Lingonberries in total": "Lingon totalt",
    "Runs": "Rundor",
    "Top runs": "Bästa rundorna",
    "No runs yet. Your best runs will show up here.": "Inga rundor än. Dina bästa rundor visas här.",
    "%1 lingonberries": "%1 lingon",

    // Inställningar
    "Theme": "Tema",
    "Automatic": "Automatiskt",
    "Light (day)": "Ljust (dag)",
    "Dark (evening)": "Mörkt (kväll)",
    "Season": "Årstid",
    "Automatic (follows the calendar)": "Automatiskt (följer kalendern)",
    "Summer": "Sommar",
    "Autumn": "Höst",
    "Winter": "Vinter",
    "Language": "Språk",
    "Automatic (system language)": "Automatiskt (systemets språk)",
    "Sound": "Ljud",
    "Background sounds": "Bakgrundsljud",
    "Sound effects": "Ljudeffekter",
    "Clear records": "Rensa rekord",
    "Clear records?": "Rensa rekorden?",
    "All saved runs and best scores will be deleted.": "Alla sparade rundor och rekord tas bort.",
    "Clear": "Rensa",
    "Cancel": "Avbryt",
    "How to play": "Så spelar du",
    "Swipe left or right to change path, up to jump over stumps and fallen trees, and down to duck under branches. You can't get past a woodpile – change path! Bumping into something from the side makes the moose stumble; stumble twice in a row and the run is over.":
        "Svep åt vänster eller höger för att byta stig, uppåt för att hoppa över stubbar och omkullfallna träd och nedåt för att ducka under grenar. Förbi en vedtrave kommer du inte – byt stig! Om älgen stöter i något från sidan snubblar den, och snubblar den två gånger i rad är rundan slut.",
    "Rubber boots let you jump higher, a gust of wind carries you through everything, and the berry basket picks berries from all three paths.":
        "Med gummistövlar hoppar du högre, en vindpust bär dig rakt igenom allt och bärkorgen plockar bär från alla tre stigarna.",
    "About": "Om",
    "Help the moose run through the Swedish forest. An original game in the endless runner genre – all characters, graphics and sounds are made for this game.":
        "Hjälp älgen att springa genom den svenska skogen. Ett eget spel i genren ändlösa löpspel – alla figurer, all grafik och alla ljud är gjorda för det här spelet.",
    "The background sounds come from Kottslungan by the same author.": "Bakgrundsljuden kommer från Kottslungan av samma upphovsperson.",
    "Version %1": "Version %1"
}

var tables = { sv: sv }

function systemLanguage(localeName) {
    return (localeName || "en").substring(0, 2) === "sv" ? "sv" : "en"
}

function tr(s, lang) {
    var t = tables[lang]
    return (t && t[s] !== undefined) ? t[s] : s
}
