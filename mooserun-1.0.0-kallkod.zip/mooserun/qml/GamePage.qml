// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

Page {
    id: page
    // Ingen rubrikrad: spelet ska fylla hela skärmen
    header: Item { height: 0; visible: false }

    property bool paused: false
    property bool showResult: false
    property int finalScore: 0
    property int finalMeters: 0
    property int finalBerries: 0
    property bool newBest: false
    property bool showHelp: root.stats.runs < 3

    function restart() {
        showResult = false
        paused = false
        showHelp = root.stats.runs < 3
        game.start()
        game.forceActiveFocus()
    }

    GameView {
        id: game
        anchors.fill: parent
        autoplay: root.autoplay
        seed: root.seed
        season: root.season
        night: root.isDark
        running: !page.paused && !page.showResult && stack.currentPage === page
        onSound: root.playSound(name)
        Component.onCompleted: { start(); forceActiveFocus() }
        onFinished: {
            page.finalScore = score
            page.finalMeters = meters
            page.finalBerries = berries
            page.newBest = score > root.stats.best
            root.saveRun(score, meters, berries)
            page.showResult = true
        }
        onMetersChanged: if (meters > 60) page.showHelp = false
    }

    // Paus när appen inte är aktiv
    Connections {
        target: Qt.application
        function onStateChanged() { if (Qt.application.state !== Qt.ApplicationActive && !page.showResult) page.paused = true }
    }

    // ---- Överst: paus, poäng, bär ------------------------------------------
    RoundButton {
        id: pauseBtn
        anchors { left: parent.left; top: parent.top; margins: units.gu(1.5) }
        iconName: "media-playback-pause"
        visible: !page.showResult
        onClicked: page.paused = true
    }
    Column {
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: units.gu(1.2) }
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            text: game.score
            font.pixelSize: units.gu(4)
            font.weight: Font.Bold
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
        }
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.tr("%1 m").arg(game.meters)
            textSize: Label.Small
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
        }
    }
    Row {
        anchors { right: parent.right; top: parent.top; margins: units.gu(1.5) }
        spacing: units.gu(0.5)
        Image {
            anchors.verticalCenter: parent.verticalCenter
            source: "../assets/lingon.svg"
            width: units.gu(3.4); height: width
            sourceSize: Qt.size(96, 96)
        }
        Label {
            anchors.verticalCenter: parent.verticalCenter
            text: game.berries
            font.pixelSize: units.gu(2.8)
            font.weight: Font.Bold
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
        }
    }

    // Kraftsaker som är igång, med en stapel för tiden som är kvar
    Column {
        anchors { right: parent.right; top: parent.top; topMargin: units.gu(7); rightMargin: units.gu(1.5) }
        spacing: units.gu(1)
        PowerBadge { source: "../assets/boots.svg"; remaining: game.boots; total: 10 }
        PowerBadge { source: "../assets/wind.svg"; remaining: game.wind; total: 5 }
        PowerBadge { source: "../assets/basket.svg"; remaining: game.basket; total: 10 }
    }

    // Hjälp de första gångerna
    Rectangle {
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: units.gu(9) }
        visible: page.showHelp && !page.showResult
        width: helpCol.width + units.gu(3); height: helpCol.height + units.gu(2)
        radius: units.gu(1.5)
        color: "#A0000000"
        Column {
            id: helpCol
            anchors.centerIn: parent
            spacing: units.gu(0.5)
            Label { text: root.tr("Swipe left or right to change path"); color: "#FFFFFF" }
            Label { text: root.tr("Swipe up to jump over stumps"); color: "#FFFFFF" }
            Label { text: root.tr("Swipe down to duck under branches"); color: "#FFFFFF" }
        }
    }

    Label {
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: parent.height * 0.3 }
        visible: game.stumbling && !game.over
        text: root.tr("Careful!")
        font.pixelSize: units.gu(3)
        font.weight: Font.Bold
        color: "#FFD54F"
        style: Text.Outline; styleColor: "#3A2A10"
    }

    // ---- Paus ------------------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        visible: page.paused && !page.showResult
        color: "#90000000"
        MouseArea { anchors.fill: parent }
        Column {
            anchors.centerIn: parent
            spacing: units.gu(2)
            Label {
                anchors.horizontalCenter: parent.horizontalCenter
                text: root.tr("Paused")
                font.pixelSize: units.gu(4); font.weight: Font.Bold
                color: "#FFFFFF"
            }
            Button {
                anchors.horizontalCenter: parent.horizontalCenter
                width: units.gu(22)
                text: root.tr("Continue")
                color: "#E8862A"
                onClicked: { page.paused = false; game.forceActiveFocus() }
            }
            Button {
                anchors.horizontalCenter: parent.horizontalCenter
                width: units.gu(22)
                text: root.tr("Quit run")
                onClicked: stack.pop()
            }
        }
    }

    // ---- Resultat --------------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        visible: page.showResult
        color: "#80000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width - units.gu(4), units.gu(40))
            height: resultCol.height + units.gu(5)
            radius: units.gu(2)
            color: theme.palette.normal.background
            border.color: theme.palette.normal.base

            Column {
                id: resultCol
                anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: units.gu(2.5) }
                spacing: units.gu(1.5)
                Label {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: page.newBest ? root.tr("New record!") : root.tr("The moose tripped!")
                    textSize: Label.Large
                    font.weight: Font.Bold
                    color: page.newBest ? theme.palette.normal.positive : theme.palette.normal.backgroundText
                }
                Label {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: page.finalScore
                    font.pixelSize: units.gu(6)
                    font.weight: Font.Bold
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: units.gu(3)
                    Column {
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: page.finalMeters; font.weight: Font.Bold; textSize: Label.Large }
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: root.tr("metres"); textSize: Label.Small; color: theme.palette.normal.backgroundSecondaryText }
                    }
                    Column {
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: page.finalBerries; font.weight: Font.Bold; textSize: Label.Large }
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: root.tr("lingonberries"); textSize: Label.Small; color: theme.palette.normal.backgroundSecondaryText }
                    }
                }
                Label {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: !page.newBest && root.stats.best > 0
                    text: root.tr("Best: %1").arg(root.stats.best)
                    color: theme.palette.normal.backgroundSecondaryText
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: units.gu(1.5)
                    Button {
                        text: root.tr("Menu")
                        onClicked: stack.pop()
                    }
                    Button {
                        text: root.tr("Run again")
                        color: "#E8862A"
                        onClicked: page.restart()
                    }
                }
            }
        }
    }
}
