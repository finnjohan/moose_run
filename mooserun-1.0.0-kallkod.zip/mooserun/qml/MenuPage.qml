// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

Page {
    id: page
    // Ingen rubrikrad: skogen fyller hela skärmen
    header: Item { height: 0; visible: false }

    // I bakgrunden springer datorspelaren genom skogen
    GameView {
        id: attract
        anchors.fill: parent
        autoplay: true
        restartOnCrash: true
        seed: root.seed >= 0 ? root.seed : -1
        season: root.season
        night: root.isDark
        running: page.visible && stack.currentPage === page
        Component.onCompleted: start()
    }
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0; color: "#90000000" }
            GradientStop { position: 0.45; color: "#30000000" }
            GradientStop { position: 1; color: "#00000000" }
        }
    }

    Column {
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: parent.height * 0.08 }
        spacing: units.gu(1.5)
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "Moose Run"
            font.pixelSize: Math.min(page.width * 0.15, units.gu(9))
            font.weight: Font.Bold
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
        }
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            width: Math.min(implicitWidth, page.width - units.gu(4))
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: root.tr("Run through the forest and pick lingonberries")
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
        }
    }

    Column {
        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: parent.height * 0.06 }
        spacing: units.gu(1.5)
        Button {
            anchors.horizontalCenter: parent.horizontalCenter
            width: units.gu(24); height: units.gu(6.5)
            text: root.tr("Run!")
            font.weight: Font.Bold
            color: "#E8862A"
            onClicked: root.play()
        }
        Item {
            anchors.horizontalCenter: parent.horizontalCenter
            visible: root.stats.runs > 0
            width: bestRow.width; height: bestRow.height
            Row {
                id: bestRow
                spacing: units.gu(1)
                Icon { name: "starred"; color: "#F2B705"; width: units.gu(2.4); height: width; anchors.verticalCenter: parent.verticalCenter }
                Label {
                    anchors.verticalCenter: parent.verticalCenter
                    text: root.tr("Best: %1").arg(root.stats.best)
                    color: "#FFFFFF"; style: Text.Outline; styleColor: "#3A2A10"
                    font.weight: Font.Bold
                }
            }
        }
    }

    Row {
        anchors { right: parent.right; top: parent.top; margins: units.gu(1.5) }
        spacing: units.gu(1)
        RoundButton { iconName: "view-list-symbolic"; onClicked: stack.push(Qt.resolvedUrl("RecordsPage.qml")) }
        RoundButton { iconName: "settings"; onClicked: stack.push(Qt.resolvedUrl("SettingsPage.qml")) }
    }
}
