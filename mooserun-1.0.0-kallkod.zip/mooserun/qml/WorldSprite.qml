// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12

// En bild i skogen (hinder, bär, träd). GameView sätter läge och storlek varje
// bildruta. sourceSize är fast, så att SVG:n bara ritas en gång och sedan
// skalas av grafikkortet.
Image {
    id: sprite
    property int objectId: -1
    property real worldW: 1
    property real worldH: 1
    property real worldX: 0
    property real worldZ: 0
    property real ratio: 1           // bildens bredd / höjd
    property bool glow: false        // kraftsaker får en ljus ring bakom sig
    property string kind: ""         // träd: spruce, pine, birch, rock
    property real pz: 0              // träd: läge längs stigen
    smooth: true
    visible: false
    fillMode: Image.Stretch

    Rectangle {
        visible: sprite.glow
        z: -1
        anchors.centerIn: parent
        width: Math.max(parent.width, parent.height) * 1.5; height: width; radius: width / 2
        color: "#60FFF4C2"
        border.color: "#C0FFE082"; border.width: Math.max(1, width * 0.04)
    }
}
